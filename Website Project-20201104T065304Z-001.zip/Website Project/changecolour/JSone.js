function changecolorblue() {
  document.body.style.backgroundColor = "blue";
}
function changecolorRed() {
  document.body.style.backgroundColor = "Red";
}
